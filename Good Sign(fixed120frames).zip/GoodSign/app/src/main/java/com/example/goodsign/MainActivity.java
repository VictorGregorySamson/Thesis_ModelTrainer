package com.example.goodsign;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import com.google.gson.Gson;
import org.tensorflow.lite.Interpreter;  // Import TensorFlow Lite interpreter
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 100;
    private static final String LOCAL_FILE = "file:///android_asset/index.html";
    private WebView myWebView;
    private Interpreter tflite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = (WebView) findViewById(R.id.webView);

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setBuiltInZoomControls(true);

        myWebView.setWebViewClient(new WebViewClient());
        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                Log.d(TAG, "onPermissionRequest");
                MainActivity.this.runOnUiThread(() -> {
                    if (request.getOrigin().toString().equals("file:///")) {
                        request.grant(request.getResources());
                    } else {
                        request.deny();
                    }
                });
            }
        });

        // Add the JavaScript interface here
        myWebView.addJavascriptInterface(new JavaInterface(), "JavaInterface");

        // Check and request camera permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST_CODE);
        } else {
            myWebView.loadUrl(LOCAL_FILE);
        }

        // Load TFLite model
        try {
            tflite = new Interpreter(loadModelFile());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load the TFLite model from assets
    private MappedByteBuffer loadModelFile() throws IOException {
        String modelPath = "model.tflite";  // Update with your model's name
        FileInputStream fileInputStream = new FileInputStream(getAssets().openFd(modelPath).getFileDescriptor());
        FileChannel fileChannel = fileInputStream.getChannel();
        long startOffset = getAssets().openFd(modelPath).getStartOffset();
        long declaredLength = getAssets().openFd(modelPath).getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                myWebView.loadUrl(LOCAL_FILE);
            } else {
                Log.d(TAG, "Camera permission denied");
            }
        }
    }

    public class JavaInterface {
        @JavascriptInterface
        public void receiveKeypoints(String keypointsJson) {
            runOnUiThread(() -> {
                Log.d(TAG, "Received keypoints: " + keypointsJson);
                Toast.makeText(MainActivity.this, "Received keypoints: " + keypointsJson, Toast.LENGTH_SHORT).show();
                processKeypoints(keypointsJson);
            });
        }
    }

    private void processKeypoints(String keypointsJson) {
        // Deserialize the JSON string to a Map
        Gson gson = new Gson();
        Map<String, List<List<Float>>> keypointsMap = gson.fromJson(keypointsJson, Map.class);

        List<List<Float>> pose = keypointsMap.get("pose");
        List<List<Float>> leftHand = keypointsMap.get("leftHand");
        List<List<Float>> rightHand = keypointsMap.get("rightHand");

        // Prepare keypoints for TFLite input (flatten and combine)
        float[] inputKeypoints = prepareInputData(pose, leftHand, rightHand);

        // Create input buffer for the TFLite model
        ByteBuffer inputBuffer = ByteBuffer.allocateDirect(inputKeypoints.length * 4); // Float size in bytes
        inputBuffer.rewind();
        for (float value : inputKeypoints) {
            inputBuffer.putFloat(value);
        }

        // Model input/output setup
        float[][] output = new float[1][actions.length]; // Assuming model predicts one-hot encoded gesture
        tflite.run(inputBuffer, output);

        // Get predicted gesture
        int predictedIndex = getMaxIndex(output[0]);
        String recognizedAction = actions[predictedIndex];
        Toast.makeText(MainActivity.this, "Predicted gesture: " + recognizedAction, Toast.LENGTH_LONG).show();
    }

    // Flatten keypoints and concatenate pose, left hand, right hand keypoints
    private float[] prepareInputData(List<List<Float>> pose, List<List<Float>> leftHand, List<List<Float>> rightHand) {
        float[] inputData = new float[pose.size() * 2 + leftHand.size() * 2 + rightHand.size() * 2];
        int index = 0;
        for (List<Float> point : pose) {
            inputData[index++] = point.get(0);
            inputData[index++] = point.get(1);
        }
        for (List<Float> point : leftHand) {
            inputData[index++] = point.get(0);
            inputData[index++] = point.get(1);
        }
        for (List<Float> point : rightHand) {
            inputData[index++] = point.get(0);
            inputData[index++] = point.get(1);
        }
        return inputData;
    }

    // Get the index of the highest score in the output array
    private int getMaxIndex(float[] output) {
        int maxIndex = 0;
        for (int i = 1; i < output.length; i++) {
            if (output[i] > output[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    // Predefined actions for gesture recognition
    private final String[] actions = {
            "GOOD MORNING", "GOOD AFTERNOON", "GOOD EVENING", "HELLO",
            "HOW ARE YOU", "IM FINE", "NICE TO MEET YOU", "THANK YOU",
            "YOURE WELCOME", "SEE YOU TOMORROW", "MONDAY", "TUESDAY",
            "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY",
            "TODAY", "TOMORROW", "YESTERDAY", "BLUE", "GREEN", "RED",
            "BROWN", "BLACK", "WHITE", "YELLOW", "ORANGE", "GRAY", "PINK",
            "VIOLET", "LIGHT", "DARK"
    };
}
